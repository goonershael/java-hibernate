package com;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class AddEvent {
	public static void main(String[] a){
		Session session = null;
		SessionFactory factory;
		Transaction tr = null;
		try{
			factory = new Configuration().configure().buildSessionFactory();
			session = factory.openSession();
			tr = session.beginTransaction();
			MyEvent e = new MyEvent();
			e.setEvent_id(1);
			e.setEvent_name("Hibernate training");
			session.save(e);
			tr.commit();
			System.out.println("Record Added ");
			session.close();
			
		}
		catch(Exception e){
			e.printStackTrace();
		}
		
		
	}
}
