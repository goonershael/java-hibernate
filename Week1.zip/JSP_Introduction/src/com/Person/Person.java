package com.Person;

public class Person {
	private String name;
	private int pID;
	
	public Person(String name, int pID) {
		super();
		this.name = name;
		this.pID = pID;
	}
	
	public Person() {
		super();
		String name;
		int pid;
	}

	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getpID() {
		return pID;
	}
	public void setpID(int pID) {
		this.pID = pID;
	}
	@Override
	public String toString() {
		return "Person [name=" + name + ", pID=" + pID + "]";
	}
	
}
