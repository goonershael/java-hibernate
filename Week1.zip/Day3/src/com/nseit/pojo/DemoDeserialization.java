package com.nseit.pojo;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.ObjectInputStream;

public class DemoDeserialization {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		FileInputStream gi = null;
		ObjectInputStream os =null;
		try {
			gi = new FileInputStream("company.txt");
			os =new ObjectInputStream(gi);
			Object o = os.readObject();
			Company co = (Company)o;
			System.out.println(co);
			} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally{
			try {
				os.close();
				gi.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			
		}
		
		
	}

}
