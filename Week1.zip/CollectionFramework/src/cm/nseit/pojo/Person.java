package cm.nseit.pojo;

import com.sun.org.apache.xpath.internal.operations.Equals;

public class Person implements Comparable{
	private String name;
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public int getAdh_num() {
		return adh_num;
	}

	public void setAdh_num(int adh_num) {
		this.adh_num = adh_num;
	}

	private int age, adh_num;
	
	public Person(){
		name = "abc";
		age = 23;
		adh_num = 31931289;
	}
	
	public Person(String name, int age, int adh_num){
		this.name = name;
		this.age = age;
		this.adh_num = adh_num;
	}

	@Override
	public String toString() {
		return "Person [name=" + name + ", age=" + age + ", adh_num=" + adh_num + "]";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + adh_num;
		result = prime * result + age;
		result = prime * result + ((name == null) ? 0 : name.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		
		return this.getAdh_num()==((Person)obj).getAdh_num();
	}

	@Override
	public int compareTo(Object obj) {
		// TODO Auto-generated method stub
		Person person = (Person)obj;
		return this.name.compareTo(person.name);
	}


}
