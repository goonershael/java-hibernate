package com.servlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.dao.StudentDAO;
import com.dao.StudentDAOImpl;

/**
 * Servlet implementation class DeleteStudent
 */
@WebServlet("/remove")
public class DeleteStudent extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public DeleteStudent() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		StudentDAO dao = new StudentDAOImpl();
		int rollno = Integer.parseInt(request.getParameter("rollno"));
		int records_inserted = dao.deleteStudent(rollno);
		//System.out.println(records_inserted);
		// Output
		response.setContentType("text/html");
		PrintWriter pw = response.getWriter();
				pw.println("<html>");
		pw.println("<body>");
		if(records_inserted>0){
			pw.println("Student  person added to database succesfully : " + rollno);
		}
		else{
			pw.println("Error :  Record couln't be deleted from the DB!!!");
		}
		pw.println("</body>");
		pw.println("</html>");
	}

}
