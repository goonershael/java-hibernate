package com.servlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.dao.StudentDAO;
import com.dao.StudentDAOImpl;
import com.pojo.Student;

/**
 * Servlet implementation class UpdateStudent
 */
@WebServlet("/update")
public class UpdateStudent extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UpdateStudent() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		Student person = new Student();
		int rollno;
		rollno =Integer.parseInt(request.getParameter("rollno"));
		String addr = request.getParameter("addr");
		//person.setName(request.getParameter("name"));
		
		//jdbc Layer
		StudentDAO dao = new StudentDAOImpl();
		Student records_updated = dao.updateStudent(rollno, addr);
		// Output
		response.setContentType("text/html");
		PrintWriter pw = response.getWriter();
				pw.println("<html>");
		pw.println("<body>");
		if(records_updated != null){
			pw.println("Record person updated to database succesfully : " );
			pw.println(records_updated);
		}
		else{
			pw.println("Error : New Record couln't be updated on the DB!!!");
		}
		pw.println("</body>");
		pw.println("</html>");
	}
}

