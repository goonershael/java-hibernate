package com.servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.dao.StudentDAO;
import com.dao.StudentDAOImpl;

import com.pojo.Student;


/**
 * Servlet implementation class FindStud
 */
@WebServlet("/find")
public class FindStud extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public FindStud() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		StudentDAO dao = new StudentDAOImpl();
		int rollno = Integer.parseInt(request.getParameter("rollno"));
		Student student =  dao.findByRollno(rollno);
		PrintWriter pw  = response.getWriter();
		pw.println("<html>");
		pw.println("<body>");
		pw.println("<table border = '1'>");
			pw.println("<tr>");
			pw.println("<td>"+student.getName()+"</td>");
			pw.println("<td>"+student.getRollno()+"</td>");
			pw.println("<td>"+student.getAddr()+"</td>");
			pw.println("<td>"+student.getTotal()+"</td>");
			pw.println("<tr>");
		pw.println("</table>");
		pw.println("</body>");
		pw.println("</html>");
	
		
	}

}
