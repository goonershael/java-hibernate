package com.entity;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class TestClass {
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Session session = null;
		SessionFactory factory;
		Transaction tr = null;
		try{

			factory = new Configuration().configure().buildSessionFactory();
			session = factory.openSession();
			tr = session.beginTransaction();

			Address address = new Address("Street", "city", "state", "zipcode");
			Employee employee = new Employee("first","last", 10000, address);
			session.save(employee);
			tr.commit();
			
			
		}catch(Exception e){
			e.printStackTrace();
		}

	}
}