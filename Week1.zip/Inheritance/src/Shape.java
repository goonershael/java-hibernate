
public abstract class Shape {
	abstract public void calcuateArea();
	
	public int concMethod(){
		return 1;		// If this function is not there in it - PURA ABSTRACTION
	}
	public static void main(String [] args){
		//Shape sh = new Shape();
	}
}


class MyShape extends Shape{

	@Override
	public void calcuateArea() {
		// TODO Auto-generated method stub
		
	}
	
}