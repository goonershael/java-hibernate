
public class DemoObjectInheritance {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Person person = new Person("Shael",12);
		Person person1 = new Person("Shael",12);
		person.show();
		System.out.println(person);
		if (person.equals(person1)){
			System.out.println("Objects are equal");
		}
		else{
			System.out.println("Objects are not equal");
		}
		
	}

}
