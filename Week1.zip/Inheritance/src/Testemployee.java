
public class Testemployee {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Person e  = new Employee("Shael", 24, 12,10000);
		e.show();
		((Employee)e).show(10);
		//e.show();
	}

}