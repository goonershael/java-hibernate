package com.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import com.connection.MyConnection;
import com.pojo.Student;

public class StudentDAOImpl implements StudentDAO {

	@Override
	public int addStudent(Student student) {
		// TODO Auto-generated method stub
		String INSERT_SQL = "insert into Student values(?,?,?,?)";
		Connection conn = MyConnection.setConnection();
		try {
			PreparedStatement ps =conn.prepareStatement(INSERT_SQL);
			ps.setString(1, student.getName());
			ps.setInt(2, student.getRollno());
			ps.setString(3, student.getAddr());
			ps.setInt(4, student.getTotal());
			int rows = ps.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			MyConnection.closeConnection();
		}
		return 1;
	}

	@Override
	public Student updateStudent(int rollno, String addr) {
		// TODO Auto-generated method stub
		Student student = null;
		String UPDATE_SQL="update Student set addr = ? where rollno = ?";
		String Search_SQL = "select * from Student  where rollno = ?";
		Connection conn = MyConnection.setConnection();
		try {
			PreparedStatement ps =conn.prepareStatement(UPDATE_SQL);
			ps.setString(1, addr);
			ps.setInt(2,  rollno);
			int rows = ps.executeUpdate();
			PreparedStatement ps1  = conn.prepareStatement(Search_SQL);
			ps1.setInt(1,  rollno);
			ResultSet rs = ps1.executeQuery();
			
			while(rs.next()){				
				student = new Student(rs.getString(1),rs.getInt(2),rs.getString(3),rs.getInt(4));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return student;
	}

	@Override
	public int deleteStudent(int rollno) {
		// TODO Auto-generated method stub
		String DELETE_SQL = "delete from Student where rollno = ?";
		Connection conn = MyConnection.setConnection();
		try {
			PreparedStatement ps =conn.prepareStatement(DELETE_SQL);
			
			ps.setInt(1, rollno);
			
			int rows = ps.executeUpdate();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			MyConnection.closeConnection();
		}
		return 1;
	}

	@Override
	public Student findByRollno(int rollno) {
		// TODO Auto-generated method stub
		Student student = null;
		String Search_SQL = "select * from Student  where rollno = ?";
		Connection conn = MyConnection.setConnection();
		try {
			PreparedStatement ps1  = conn.prepareStatement(Search_SQL);
			ps1.setInt(1,  rollno);
			ResultSet rs = ps1.executeQuery();
			
				while(rs.next()){				
					student = new Student(rs.getString(1),rs.getInt(2),rs.getString(3),rs.getInt(4));
				}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return student;
	}

	@Override
	public List<Student> findByName(String name) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Student> findByAddress(String addr) {
		// TODO Auto-generated method stub
		return null;
	}

}
