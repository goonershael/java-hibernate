package com.connection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

public class DemoPrepared {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Connection connection = MyConnection.setConnection();
		System.out.println("Connection Established - success!!");
		String INSERT_SQL = "insert into Person values(?,?,?)";
		try {
			PreparedStatement ps = connection.prepareStatement(INSERT_SQL);
			
			Scanner scanner  = new Scanner(System.in);
			System.out.println("Enter name : ");
			String name = scanner.nextLine();
			System.out.println("Enter age : ");
			int age = scanner.nextInt();
			System.out.println("Enter aadhar_num : ");
			int adh_num = scanner.nextInt();
			
			ps.setString(1, name);
			ps.setInt(2, age);
			ps.setInt(3, adh_num);
			int rows = ps.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			MyConnection.closeConnection();
		}
	}

}
