import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.sql.SQLException;

public class DemoTranscation {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Connection conn = null;
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			 conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl","scott", "tiger");
			System.out.println("connection successful");
			conn.setAutoCommit(false);
			Statement statement = conn.createStatement();

			String SQL_INSERT= "insert into Person values('shael1',24,95895)";
			int rows = statement.executeUpdate(SQL_INSERT);
			String SQL_INSERT1= "insert into Person values('shael1',24,95895)";
			statement.executeUpdate(SQL_INSERT1);
			String SQL_INSERT2= "insert into Person values('shael1',24,95895)";
			statement.executeUpdate(SQL_INSERT2);
			// Add to permanent memory operation here :
			conn.commit();
			if(rows>0){
				System.out.println("Rows Inserted ");
			}
		}catch(SQLException  e){
			try {
				conn.rollback();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			e.printStackTrace();
			
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	

}
