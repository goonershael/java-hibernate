package com.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.connection.MyConnection;
import com.pojo.Login;

public class customerDAOImpl implements customerDAO {
	Connection connection = MyConnection.setConnection();
	@Override
	public boolean compareBy(String username, String password) {
		// TODO Auto-generated method stub
		Login customer = new Login();
		String COMPARE_SQL="select* from Login where username=? and password=?";
		boolean flag = false;
		try {
			PreparedStatement ps=connection.prepareStatement(COMPARE_SQL);
			String userpk =null;
			String pass =null;
			ps.setString(1,username);
			ps.setString(2, password);
			ResultSet resultSet = ps.executeQuery();
			while(resultSet.next()){
			//	userpk=resultSet.getString(1);
				//pass=resultSet.getString(2);
				
			flag=true;
			}
		
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return flag;
		
		
	}

	@Override
	public int addCustomer(Login customer) {
		// TODO Auto-generated method stub
		
		int records =0;
		String INSERT_SQL="insert into Login values(?,?,?,?)";
			try {
				PreparedStatement ps = connection.prepareStatement(INSERT_SQL);
				ps.setString(1, customer.getUsername());
				ps.setString(2, customer.getPassword());
				ps.setString(3,customer.getName());
				ps.setString(4, customer.getAddress());
				records =ps.executeUpdate();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		
		
		return records;
	}

}
