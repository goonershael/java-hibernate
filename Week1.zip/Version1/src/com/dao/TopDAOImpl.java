package com.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.pojo.PizzaToppings;

public class OrderDAOImpl implements OrderDAO {

	@Override
	public List<PizzaToppings> showList() {
		// TODO Auto-generated method stub
		List<PizzaToppings> pizza = new ArrayList<>();
		Connection conn = com.connections.MyConnection.setConnection();
		String LIST_ALL = "select * from Pizza";
		try {
			PreparedStatement ps = conn.prepareStatement(LIST_ALL);
			ResultSet rs =ps.executeQuery();
			while (rs.next()) {
				PizzaToppings pizzat = new PizzaToppings();
				pizzat.setName(rs.getString(1));
				pizzat.setID(rs.getInt(2));
				
			
				pizzat.setPrice(rs.getInt(3));
				
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return pizza;
	}

}
