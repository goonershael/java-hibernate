package com.dao;
public interface BillingDAO {
	public int billCalc(int price, int top, int extra);
}