package com.dao;

import com.pojo.Login;

public interface customerDAO {
	
	 boolean compareBy(String username,String password);
	 int addCustomer(Login customer);

}
