package com.dao;

import java.util.List;

import com.pojo.Pizza;

public interface OrderDAO {
	/*
	 * This pizza interface is for customer 
	 * Add pizza selection (customer side ) functions here 
	 */
	public List<Pizza> showList();
	
}
