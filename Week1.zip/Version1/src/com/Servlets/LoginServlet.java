package com.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.dao.customerDAO;
import com.dao.customerDAOImpl;
import com.login.Login;

/**
 * Servlet implementation class LoginServlet
 */
@WebServlet("/login")
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public LoginServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		Login customer=new Login();
	
	
		customerDAO dao= new customerDAOImpl();
		boolean compareVal;
		String uname=request.getParameter("username");
		String pass=request.getParameter("password");
		compareVal=	dao.compareBy(uname,pass);

	
		response.setContentType("text/html");
		PrintWriter writer = response.getWriter();
		
		writer.println("<html>");
		writer.println("<body>");
		
		if(compareVal==true){
			writer.println("Welcome! Order your PIZZA!!!!!");
				
		}
		else{
			writer.println("Sorry!! Login Again");
		}
		writer.println("</html>");
		writer.println("</body>");
	
	}
	

	}


