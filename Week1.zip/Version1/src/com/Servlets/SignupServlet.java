package com.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.dao.customerDAO;
import com.dao.customerDAOImpl;
import com.login.Login;


/**
 * Servlet implementation class AddServlet
 */
@WebServlet("/signup")
public class SignupServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public SignupServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	
	Login customer=new Login();
		customer.setUsername(request.getParameter("username"));
		customer.setPassword(request.getParameter("password"));
		customer.setName(request.getParameter("name"));
		customer.setAddress(request.getParameter("address"));
		
		customerDAO dao= new customerDAOImpl();
		int signedup =dao.addCustomer(customer);
		System.out.println(signedup);
		
		response.setContentType("text/html");
		PrintWriter writer = response.getWriter();
		
		writer.println("<html>");
		writer.println("<body>");
		
		if(signedup>0){
			writer.println("Welcome"+customer.getName());
				
		}
		else{
			writer.println("Sorry!! Signup Again");
		}
		writer.println("</html>");
		writer.println("</body>");
	
	}
	

	
	
	

}
