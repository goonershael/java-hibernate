package com.Servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.dao.OrderDAO;
import com.dao.OrderDAOImpl;
import com.pojo.Pizza;

import jdk.nashorn.internal.ir.RuntimeNode.Request;

/**
 * Servlet implementation class ShowPizza
 */
@WebServlet("/show")
public class ShowPizza extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ShowPizza() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		OrderDAO dao=  new OrderDAOImpl();
		List<Pizza>pizzas = null;
		pizzas = dao.showList();
		/*
		for(Pizza pizza : pizzas){
			System.out.println(pizza);
		}
		response.setContentType("text/html");
		PrintWriter pw = response.getWriter();
		pw.println("<html>");
		pw.println("<body>");
		pw.println("Pizzas");
		pw.println("<table border = '3'>");
		for(Pizza pizza: pizzas){
			pw.println("<tr>");
			pw.println("<td>"+pizza.getName()+"<input type='button' "+"</td>");
			pw.println("<td>"+pizza.getDescription()+"</td>");
			pw.println("<td>"+pizza.getType()+"</td>");
			pw.println("<td>"+pizza.getPrice()+"</td");
					
			pw.println("<tr>");
		}
		pw.println("</table>");
		pw.println("</body>");
		pw.println("</html>");
		
	}*/
	request.setAttribute("pizzas", pizzas);
	// add dispatching - using request dispatcher
	RequestDispatcher dispatcher = request.getRequestDispatcher("showPizza.jsp");
	dispatcher.forward(request, response);

	}
}
