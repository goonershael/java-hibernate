package com.pojo;



public class Crust {
private int crustid;
private String crustname;
public int getCrustid() {
	return crustid;
}
public void setCrustid(int crustid) {
	this.crustid = crustid;
}
public String getCrustname() {
	return crustname;
}
public void setCrustname(String crustname) {
	this.crustname = crustname;
}
public int getCrustprize() {
	return crustprize;
}
public void setCrustprize(int crustprize) {
	this.crustprize = crustprize;
}
private int crustprize;


public Crust(){
	crustid=0;
	crustname=null;
	crustprize=0;
}
}
