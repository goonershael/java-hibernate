package com.pojo;

public class Toppings {
private int top_id;
private String top_name;
private int top_prize;
public int getTop_id() {
	return top_id;
}
public void setTop_id(int top_id) {
	this.top_id = top_id;
}
public String getTop_name() {
	return top_name;
}
public void setTop_name(String top_name) {
	this.top_name = top_name;
}
public int getTop_prize() {
	return top_prize;
}
public void setTop_prize(int top_prize) {
	this.top_prize = top_prize;
}
public Toppings(){
	int top_id=0;
	String top_name=null;
	int top_prize=0;
}

}
