import java.util.Scanner;

public class CompanyMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
			Logic log = new Logic();
			String name, addr;
			Company [] co;
			co = new Company[5];
			
			Scanner scanner = new Scanner (System.in);
			for(int i =0; i<co.length; i++){
				System.out.println("Enter Co. name : ");
				name  = scanner.next();
				System.out.println("Enter Co. location : ");
				addr = scanner.next();
				
				co[i] = new Company(name,addr);
			}
			//nseit
			log.addCompany(co);
			log.showCompany();
		}
	
}