package com.service;

public class Addition {
	public int add(int x, int y){
		int res = 0 ;
		res = x+ y;
		return res;
		
	}
	public double div(int x, int y){
		double res = 0.0 ;
		res = x/ y;
		return res;
		
	}
	
}
