package com.service.test;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.service.Addition;

public class testAdd {

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testAdd() {
		//fail("Not yet implemented");
		Addition add = new Addition();
		int x = 10, y =20;
		//int expected = x+y;
		int actual = add.add(x, y);
		assertEquals(30, actual);
		
	}
	@Test
	public void testAddNegative() {
		//fail("Not yet implemented");
		Addition add = new Addition();
		int x = 10, y =20;
		//int expected = x+y;
		int actual = add.add(x, y);
		assertTrue(300!= actual);
		
	}
}
