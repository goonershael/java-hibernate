package com.entity;

import java.text.SimpleDateFormat;
import java.util.Date;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class PersonTestClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Session session = null;
		SessionFactory factory;
		Transaction tr = null;
		try{

			factory = new Configuration().configure().buildSessionFactory();
			session = factory.openSession();
			tr = session.beginTransaction();
/*
			 Person person = new Person("random","person");
			session.save(person);
			session.getTransaction().commit();
			
			 
			
			SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy/mm/dd");
			String date = "2017/07/19";
			Date date2 = dateFormat.parse(date); 
			
			Employee employee = new Employee("emplyee", "one", date2, "Sales");
			session.beginTransaction();
			session.save(employee);
			session.getTransaction().commit();
			
			*/
			
			session.beginTransaction();
			Employee person_ser = (Employee) session.get(Person.class,  1L);
			System.out.println(person_ser.getFirstname());
			session.close();
		}catch(Exception e){
			e.printStackTrace();
		}
	}

}
