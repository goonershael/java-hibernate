package com.entity;

import java.util.Date;

public class Employee extends Person {
	private Date joiningDate;
	private String departmentName;
	public Employee(){}
	public Employee(String fname, String lname, Date date, String dept) {
		super(fname, lname);
		this.joiningDate = date;
		this.departmentName = dept;
	}
	public Date getJoiningDate() {
		return joiningDate;
	}
	public void setJoiningDate(Date joiningDate) {
		this.joiningDate = joiningDate;
	}
	public String getDepartmentName() {
		return departmentName;
	}
	public void setDepartmentName(String departmentName) {
		this.departmentName = departmentName;
	}
}
