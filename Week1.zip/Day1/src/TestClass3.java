
public class TestClass3{
	private int rollNo;
	private String  name;
	private int sub1, sub2, sub3;
	
	public int getRollNo() {
		return rollNo;
	}

	public void setRollNo(int rollNo) {
		this.rollNo = rollNo;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getSub1() {
		return sub1;
	}

	public void setSub1(int sub1) {
		this.sub1 = sub1;
	}

	public int getSub2() {
		return sub2;
	}

	public void setSub2(int sub2) {
		this.sub2 = sub2;
	}

	public int getSub3() {
		return sub3;
	}

	public void setSub3(int sub3) {
		this.sub3 = sub3;
	}

	public void display(){
		System.out.println("roll No. "+rollNo + "\nName : " +name + "\nsubject 1 marks : "+sub1 + "\nsubject 2 marks : " + sub2 + "\nSubject 3 marks : " + sub3);
	}
	
	public TestClass3(){
		name = "Sahil";
		rollNo = 92384728;
		sub1 = 50;
		sub2 = 70;
		sub3 = 100;
	}
	public  TestClass3(int roll, String nam, int s1, int s2, int s3){
		name = nam;
		rollNo = roll;
		sub1 = s1;
		sub2 = s2;
		sub3 = s3;
	}
	
	public void setsub2Val(int a){
		 a  = 10;
	}
	public static void main(String[] args){
		TestClass3 t = new TestClass3();
		t.display();
		TestClass3 t1 = new TestClass3(32781873, "Shael", 80,32 , 74);
		t1.display();
		int x, y;
		x = t1.getSub2();
		y = t.getSub2();
		t.setSub2(x);
		t.display();
		
	}
}
