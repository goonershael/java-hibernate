package Assignment;

public class Triangle {
	
	private int side1, side2;
	private float area;

	public float getArea() {
		return area;
	}

	public void setArea(float area) {
		this.area = area;
	}

	public int getSide1() {
		return side1;
	}

	public void setSide1(int side1) {
		this.side1 = side1;
	}

	public int getSide2() {
		return side2;
	}

	public void setSide2(int side2) {
		this.side2 = side2;
	}
	
	public Triangle(int side1, int side2){
		this.side1 = side1;
		this.side2 = side2;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Triangle t  = new Triangle(4, 3);
		TriangleMani tm =  new TriangleMani();
		float area = 0;
		area = tm.calcArea(t);
		t.setArea(area);
		System.out.println("Area of triangle : " + t.getArea());
		
	}

}