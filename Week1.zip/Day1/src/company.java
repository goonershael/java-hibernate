
public class company {
	private String name;
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public int getNumEmp() {
		return numEmp;
	}

	public void setNumEmp(int numEmp) {
		this.numEmp = numEmp;
	}

	private String address, type;
	private int numEmp;
	
	public company(String nam, String addr, String t, int n){
		name = nam;
		address = addr;
		type = t;
		numEmp = n;
	}
	
	public void display(){
		System.out.println("Co. Name: " + name + "\nCo. Addr. : " + address + "\nTyp  : " + type + "\nNo. of employees:" + numEmp);
	}
	
	public static void main(String [] args){
		company comp1  = new company("Cisco", "2372 Mumabi", "Networking IT", 12000);
		company comp2  = new company("NSEIT", "23, Mumbai", "SoftwareIT", 1400);
		company comp3  = new company("NSE", "Bandra Kurla ", "Trading", 5000);
		comp1.display();
		System.out.println();
		comp2.display();
		System.out.println();
		comp3.display();
		String sx = comp2.getAddress();
		comp2.setAddress("Andheri");
		System.out.println("After Change\n");
		comp2.display();
		System.out.println("Before  Change\n");
		comp2.setAddress(sx);
		comp2.display();
	}
}
