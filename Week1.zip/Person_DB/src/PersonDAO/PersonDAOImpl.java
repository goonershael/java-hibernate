package PersonDAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.Connections.MyConnection;
import com.pojo.Person;

public class PersonDAOImpl implements PersonDAO {

	@Override
	public int addPerson(Person person) {
		// TODO Auto-generated method stub
		int records =1;
		Connection connection = MyConnection.setConnection();
		String INSERT_SQL = "insert into Person values(?,?,?)";
		try {
			PreparedStatement ps = connection.prepareStatement(INSERT_SQL);
			ps.setString(1,person.getName());
			ps.setInt(2, person.getAge());
			ps.setInt(3, person.getAdh_num());
			records = ps.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			MyConnection.closeConnection();
		}
		return 1;
	}

	@Override
	public boolean updatePerson(int adh_num, int age) {
		// TODO Auto-generated method stub\
		int records =1;
		boolean record = false;
		Connection connection = MyConnection.setConnection();
		String INSERT_SQL = "update Person set age=? where adh_num = ?";
		try {
			PreparedStatement ps = connection.prepareStatement(INSERT_SQL);
			//ps.setString(1,person.getName());
			ps.setInt(1, age);
			ps.setInt(2, adh_num);
			records = ps.executeUpdate();
			if(records > 0){
				record = true;
			}
			else{
				record = false;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			MyConnection.closeConnection();
		}
		return record;
	}

	@Override
	public List<Person> showPerson(int adh_num) {
		// TODO Auto-generated method stub
		List<Person> persons = new ArrayList<>();
		Connection conn = MyConnection.setConnection();
		String display_Query = "select * from Person where adh_num =?";
		try {
			PreparedStatement ps = conn.prepareStatement(display_Query);
			ps.setInt(1, adh_num);
			ResultSet rs = ps.executeQuery();
			while(rs.next()){
				Person person = new Person();
				person.setName(rs.getString(1));
				person.setAge(rs.getInt(2));
				person.setAdh_num(rs.getInt(3));
				persons.add(person);
				
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			MyConnection.closeConnection();
		}
		return persons;
	}

	@Override
	public List<Person> showAll() {
		// TODO Auto-generated method stub
		
		List<Person> persons = new ArrayList<>();
		Connection conn = MyConnection.setConnection();
		String display_Query = "select * from Person";
		try {
			PreparedStatement ps = conn.prepareStatement(display_Query);
			//ps.setInt(1, adh_num);
			ResultSet rs = ps.executeQuery();
			while(rs.next()){
				Person person = new Person();
				person.setName(rs.getString(1));
				person.setAge(rs.getInt(2));
				person.setAdh_num(rs.getInt(3));
				persons.add(person);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			MyConnection.closeConnection();
		}
		return persons;
	}

}
