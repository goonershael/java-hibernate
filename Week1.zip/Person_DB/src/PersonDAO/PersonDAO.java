package PersonDAO;

import java.util.List;

import com.pojo.Person;

public interface PersonDAO {
	public int addPerson(Person person);
	public boolean updatePerson(int adh_num, int age);
	List<Person> showPerson(int adh_num);
	List<Person> showAll();
}
