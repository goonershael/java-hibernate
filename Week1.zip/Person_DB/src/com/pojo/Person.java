package com.pojo;

public class Person {
	private String name;
	private int age, adh_num;
	
	public Person(){
		name = "";
		age = adh_num = 0;
	}

	public String getName() {
		return name;
	}

	public Person(String name, int age, int adh_num) {
		super();
		this.name = name;
		this.age = age;
		this.adh_num = adh_num;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}


	public int getAdh_num() {
		return adh_num;
	}

	public void setAdh_num(int adh_num) {
		this.adh_num = adh_num;
	}

	@Override
	public String toString() {
		return "Person [name=" + name + ", age=" + age + ", adh_num=" + adh_num + "]";
	}
}
