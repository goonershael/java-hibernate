package com.MyServlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.pojo.Person;

import PersonDAO.PersonDAO;
import PersonDAO.PersonDAOImpl;

/**
 * Servlet implementation class UpdatePerson
 */
@WebServlet("/update")
public class UpdatePerson extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UpdatePerson() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		Person person = new Person();
		int age, adh_num;
		//person.setName(request.getParameter("name"));
		age =Integer.parseInt(request.getParameter("age"));
		adh_num = Integer.parseInt(request.getParameter("adh_num"));
		//jdbc Layer
		PersonDAO dao = new PersonDAOImpl();
		boolean records_updated = dao.updatePerson(adh_num, age);
		//System.out.println(records_inserted);
		// Output
		response.setContentType("text/html");
		PrintWriter pw = response.getWriter();
				pw.println("<html>");
		pw.println("<body>");
		if(records_updated = true){
			pw.println("Record person updated to database succesfully : " );
		}
		else{
			pw.println("Error : New Record couln't be updated on the DB!!!");
		}
		pw.println("</body>");
		pw.println("</html>");
	}

}
