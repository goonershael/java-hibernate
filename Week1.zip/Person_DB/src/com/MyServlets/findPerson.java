package com.MyServlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.pojo.Person;

import PersonDAO.PersonDAO;
import PersonDAO.PersonDAOImpl;

/**
 * Servlet implementation class findPerson
 */
@WebServlet("/find")
public class findPerson extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public findPerson() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		
		
		PersonDAO dao = new PersonDAOImpl();
		int adh_num = Integer.parseInt(request.getParameter("adh_num"));
		List<Person>persons = dao.showPerson(adh_num);
		PrintWriter pw  = response.getWriter();
		pw.println("<html>");
		pw.println("<body>");
		pw.println("<table border = '1'>");
		for(Person person: persons){
			pw.println("<tr>");
			pw.println("<td>"+person.getName()+"</td>");
			pw.println("<td>"+person.getAge()+"</td>");
			pw.println("<td>"+person.getAdh_num()+"</td>");
			pw.println("<tr>");
		}
		pw.println("</table>");
		pw.println("</body>");
		pw.println("</html>");
	
		
		
	}

}
