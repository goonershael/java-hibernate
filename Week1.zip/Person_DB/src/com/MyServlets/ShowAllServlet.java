package com.MyServlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import com.pojo.Person;

import PersonDAO.PersonDAO;
import PersonDAO.PersonDAOImpl;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import PersonDAO.PersonDAO;
import PersonDAO.PersonDAOImpl;

/**
 * Servlet implementation class ShowAllServlet
 */
@WebServlet("/show")
public class ShowAllServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ShowAllServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		
		PersonDAO dao = new PersonDAOImpl();
		List<Person>persons = dao.showAll();
		/*
		PrintWriter pw  = response.getWriter();
		
		pw.println("<html>");
		pw.println("<body>");
		pw.println("<table border = '3'>");
		for(Person person: persons){
			pw.println("<tr>");
			pw.println("<td>"+person.getName()+"</td>");
			pw.println("<td>"+person.getAge()+"</td>");
			pw.println("<td>"+person.getAdh_num()+"</td>");
			pw.println("<tr>");
		}
		pw.println("</table>");
		pw.println("</body>");
		pw.println("</html>");
		*/
		
		// Adding resusabilty tyo the code using atributes
		request.setAttribute("list" ,persons);
		// add displateching - using erquesst displatcher
		RequestDispatcher dispatcher = request.getRequestDispatcher("home.jsp");
		dispatcher.forward(request, response);
		
	}

}
