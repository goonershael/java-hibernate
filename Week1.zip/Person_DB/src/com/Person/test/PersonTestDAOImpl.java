package com.Person.test;

import static org.junit.Assert.*;

import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.pojo.Person;

import PersonDAO.PersonDAO;
import PersonDAO.PersonDAOImpl;

public class PersonTestDAOImpl {

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testAddPerson() {
//		fail("Not yet implemented");
		Person person= new Person("test Person", 10, 100);
		PersonDAO dao = new PersonDAOImpl();
		int r = dao.addPerson(person);
		assertEquals(1,r);
	}
	
	@Test
	public void testADdPersonNegative(){
		Person person= new Person("test Person", 10, 100);
		PersonDAO dao = new PersonDAOImpl();
		int r = dao.addPerson(person);
		assertEquals(0,r);
		assertTrue(r==0);
		assertTrue(r!=1);
	}
	
	@Test(expected = java.sql.SQLException.class)
	public void testPersonException(){
		Person person= new Person("test Person", 10, 100);
		PersonDAO dao = new PersonDAOImpl();
		int r = dao.addPerson(person);
	}
	
	@Test
	public void testShowAll(){
		PersonDAO dao = new PersonDAOImpl();
		List<Person> list= dao.showAll();
		assertEquals(8, list.size());
		Person person  =list.get(0);
		assertEquals("sahil",person.getName());
		assertEquals(24,person.getAge());
		assertEquals(36123,person.getAdh_num());
	}
}
