
public class Logic implements StudentImpl {
	
	
	@Override
	public int total(Student student) {
		// TODO Auto-generated method stub
		int total = 0;
		int [] arr = new int [5];
		arr = student.getMarks(); 
		total = arr[0] + arr[1] +arr[2] +arr[3] +arr[4] ; 
		return total;
		
	}
	@Override
	public float percent(int total) {
		// TODO Auto-generated method stub
		float percent = 0;
		percent = total/ 5;
		return percent;
	}
	@Override
	public Student selectTopper(Student[] student) {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public int highMArks(Student[] student) {
		// TODO Auto-generated method stub
		int [] marks = new int [5];
		marks[0] = 0;
		int total = 0;
		int max = 0 ;
		for (int i= 0; i< student.length; i++){
			marks = student[i].getMarks();
			total = marks[0] + marks[1] +marks[2] +marks[3] +marks[4];
			if(total > max){
				max  = total;
			}
			
		}
		return max;
		}
}
