
public interface StudentImpl {
	public int total(Student student);
	public float percent (int total);
	public Student selectTopper(Student[]  student);
	public int highMArks(Student[] student);
}
