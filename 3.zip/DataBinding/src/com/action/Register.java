package com.action;

import com.dao.UserDAO;
import com.dao.UserDAOImpl;
import com.domain.User;
import com.opensymphony.xwork2.ActionSupport;

public class Register extends ActionSupport {
	User user;

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
		System.out.println("user name : " + user.getName());
	}
	
	public String execute(){
		UserDAO dao = new UserDAOImpl();
		dao.addUser(user);
		return SUCCESS;
	}
}
