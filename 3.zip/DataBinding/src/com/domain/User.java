package com.domain;

import java.util.Date;

public class User {
	public User() {
		// TODO Auto-generated constructor stub
	}
	
	public Date birthDate;
	public Date getBirthDate() {
		return birthDate;
	}
	public void setBirthDte(Date birthDate) {
		this.birthDate = birthDate;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getPortfolioName() {
		return portfolioName;
	}
	public void setPortfolioName(String portfolioName) {
		this.portfolioName = portfolioName;
	}

	public String name;
	public String password;
	public String portfolioName;
	
}
