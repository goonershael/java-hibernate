package com.dao;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.Date;

import com.connection.MyConnection;
import com.domain.User;
import com.mysql.jdbc.PreparedStatement;

public class UserDAOImpl implements UserDAO {

	@Override
	public int addUser(User user) {
		// TODO Auto-generated method stub
		int record = 0;
		Connection connection = MyConnection.setConnection();
		User user1 = new User();
		String name = user1.getName();
		String portfolioName = user1.getPortfolioName();
		Date DOB= user1.getBirthDate();
		String ADD = "insert into Users values(?,?,?,?)";
		PreparedStatement ps;
		try {
			ps = (PreparedStatement) connection.prepareStatement(ADD);
			ps.setString(1,user.getName());
			ps.setString(2, user.getPortfolioName());
			java.sql.Date date = new java.sql.Date(user.getBirthDate().getTime());
			ps.setDate(3,  date);
			ps.setString(4,user.getPassword());
			record = ps.executeUpdate();
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		finally{
			MyConnection.closeConnection();
		}
		return record;
	}

}
