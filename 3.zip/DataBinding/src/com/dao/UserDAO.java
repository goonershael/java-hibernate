package com.dao;

import com.domain.User;

public interface UserDAO {
	int addUser(User user);
}
