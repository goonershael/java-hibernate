package com.action;

import com.domain.User;
import com.opensymphony.xwork2.ActionSupport;
import com.opensymphony.xwork2.ModelDriven;
import com.opensymphony.xwork2.Preparable;

public class Register extends ActionSupport implements ModelDriven, Preparable{
	private User user;

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	@Override
	public void prepare() throws Exception {
		// TODO Auto-generated method stub
		System.out.println("preap");
		user = new User();
	try{
		Thread.sleep(100);
	}catch(InterruptedException e){
		e.printStackTrace();
	}
	}

	@Override
	public Object getModel() {
		// TODO Auto-generated method stub
		System.out.println("getmodel()");
		try {
			Thread.sleep(100);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return user;
	}
	
	public String execute(){
		System.out.println(user.getName() + " " + user.getPortfolioName());
		return SUCCESS;
		
	}
}
