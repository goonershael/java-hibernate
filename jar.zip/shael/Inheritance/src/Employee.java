
public class   Employee  extends Person {
	private int empId, salary;
	public Employee(){
		
	}
	public Employee(String name, int age, int empId, int salary){
		super(name, age);
		this.empId = empId;
		this.salary = salary;
	}
	
	public void show (){
		super.show();
		System.out.println(empId + "\t" +  salary);
	}
	public void show (int x){
		System.out.println(empId + "\t" +  salary);
	}

}
