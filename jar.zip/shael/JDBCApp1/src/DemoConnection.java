import java.sql.Statement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;

public class DemoConnection {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl","scott", "tiger");
			
//			Statement statement = conn.createStatement();
//			String SQL_INSERT = "insert into Person values('aditya', 24, 212312)";
//			int rows = statement.executeUpdate(SQL_INSERT);
//			if (rows != 0){
//				System.out.println("connection established - SUCCESS!");}
			Statement statement = conn.createStatement();
			String SQL_GETDATA= "select * from Person";
			ResultSet set = statement.executeQuery(SQL_GETDATA);
			//System.out.println(set.);
			while(set.next()){
				String name = set.getString("name");
				int age =set.getInt("age");
				int adh_num = set.getInt("adh_num");
				System.out.println(name + "\t" + age + "\t" + adh_num);
			}
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}
