package com.MyServlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.pojo.Person;

import PersonDAO.PersonDAO;
import PersonDAO.PersonDAOImpl;

/**
 * Servlet implementation class AddPersonServlet
 */
@WebServlet("/addMe")
public class AddPersonServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AddPersonServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		Person person = new Person();
		person.setName(request.getParameter("name"));
		person.setAge(Integer.parseInt(request.getParameter("age")));
		person.setAdh_num(Integer.parseInt(request.getParameter("adh_num")));
		//jdbc Layer
		PersonDAO dao = new PersonDAOImpl();
		int records_inserted = dao.addPerson(person);
		//System.out.println(records_inserted);
		// Output
		response.setContentType("text/html");
		PrintWriter pw = response.getWriter();
				pw.println("<html>");
		pw.println("<body>");
		if(records_inserted>0){
			pw.println("New person added to database succesfully : " + person.getName() + "\t" + person.getAge() + "\t"+ person.getAdh_num());
		}
		else{
			pw.println("Error : New Record couln't be added to the DB!!!");
		}
		pw.println("</body>");
		pw.println("</html>");
	
	}

}
