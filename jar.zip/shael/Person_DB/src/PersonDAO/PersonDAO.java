package PersonDAO;

import com.pojo.Person;

public interface PersonDAO {
	public int addPerson(Person person);
	public boolean updatePerson(int adh_num, int age);
}
