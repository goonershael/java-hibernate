
public class ArrayTest1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int arr[];
		arr = new int [5];
		arr[0] = 4;
		arr[1] = 20;
		arr[2] = 545;
		System.out.println("Index 0 : " + arr[0]);

		System.out.println("Index 2 : " + arr[2]);

		System.out.println("Index 4 : " + arr[4]); //dEFAult value printed
		
		for (int i=0; i < arr.length; i++){

			System.out.println("Index " + i + " :" + arr[i]);
		}
		
		for (int i: arr ){
			System.out.println("Value  " + i );
		}
	}

}
