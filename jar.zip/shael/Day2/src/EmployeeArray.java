
public class EmployeeArray {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Employee []  emp;
		emp = new Employee[3];
		emp[0] = new Employee();
		emp[1] = new Employee("Shael", 32344, 10000);
		emp[2] = new Employee("Sahil", 323244, 12000);
		
		for (int i = 0 ; i <emp.length; i ++ ){
			System.out.println("Employee name " + emp[i].getEname() + "\nEmpolyee ID  : " + emp[i].getEid());
		}
		
		for (Employee e : emp){
			System.out.println("Employee name " + e.getEname() + "\tEmpolyee ID  : " + + e.getEid());
		}
	}

}
