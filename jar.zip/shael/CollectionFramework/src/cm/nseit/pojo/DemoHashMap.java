package cm.nseit.pojo;

import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.HashMap;
import java.util.Iterator;

public class DemoHashMap {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Map<String, Person> map = new HashMap<>();
		map.put("A", new Person());
		map.put("B", new Person("shael", 24, 387218312));
		map.put("C", new Person("shael", 24, 387218312));
		map.put("B", new Person("shael", 4, 657342));
		map.put("A", new Person("shael", 14, 43218312));
		map.put("D", new Person("shael", 14, 43218312));
		System.out.println("Size: "+ map.size());
		System.out.println(map);
		
		Set<Entry<String,Person>> set = map.entrySet();
		Iterator<Entry<String, Person>> iterator = set.iterator();
		while(iterator.hasNext()){
			Entry<String, Person> entry = iterator.next();
			System.out.println(entry.getKey()+"\t" + entry.getValue()); 
		}
	}
	

}
