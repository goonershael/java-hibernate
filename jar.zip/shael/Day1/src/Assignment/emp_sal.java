package Assignment;

public class emp_sal {
	public Employee employ(Employee emp){
		Employee emp1 = null;
		emp1 = emp;
		return emp1;
	}
	
	public int calcuateSalary(Employee emp){
		int gross = 0;
		int basic = 0;
		basic = emp.getB_sal();
		if (basic >= 10000 && basic<=15000){
			gross  = basic + (basic/2); 
		}
		else if (basic < 10000 ){
			gross  = basic + (basic/4);
		}
		
		else {
			gross  = basic + (3*(basic/4));
		}
		
		return gross;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
