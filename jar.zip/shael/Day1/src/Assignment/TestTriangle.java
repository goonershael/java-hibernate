package Assignment;

public class TestTriangle {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Triangle t = new Triangle(8,6);
		TriangleMani tm = new TriangleMani();
		System.out.println("Area of the triangle : " + tm.calcArea(t));
		
		
	}

}
