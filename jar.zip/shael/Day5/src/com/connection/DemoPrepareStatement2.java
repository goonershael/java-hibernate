package com.connection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

public class DemoPrepareStatement2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Connection connection = MyConnection.setConnection();
		String Search_SQL = "select * from Person where adh_num = ?";
		String Search_SQL1 = "select * from Person where age = ?";
		String Alter_SQL = "update Person set age = ? where adh_num = ? ";
		try {
			PreparedStatement ps  = connection.prepareStatement(Search_SQL);
			Scanner scanner =  new Scanner(System.in);
			System.out.println("Search person with aadhar num : ");
			int adh_num = scanner.nextInt();
			
			ps.setInt(1, adh_num);
			ResultSet rs = ps.executeQuery();
			while(rs.next()){
				System.out.println(rs.getString(1)+"\t" + rs.getInt(2)+"\t"+ rs.getInt(3));
				
			}
			System.out.println("Update Age of user : ");
			int age = scanner.nextInt();
			PreparedStatement ps1  = connection.prepareStatement(Alter_SQL);
			ps1.setInt(1, age);
			ps1.setInt(2, adh_num);
//			while(rs1.next()){
//				System.out.println(rs1.getString(1)+"\t" + rs1.getInt(2)+"\t"+ rs1.getInt(3));
//				
//			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			MyConnection.closeConnection();
		}
				
		
	}

}
