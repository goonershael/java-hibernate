package package1;

public class MyClass {
	protected  void add(){
	}
	public void testAdd(){
		add();
	}
}
