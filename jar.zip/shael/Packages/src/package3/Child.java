package package3;

import package1.MyClass;

public class Child extends MyClass {
	public void show(){
		add();
	}
}
