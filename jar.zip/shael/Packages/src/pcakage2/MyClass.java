package pcakage2;

public class MyClass {
	 public void subtract(){
		
	}
	 
}
