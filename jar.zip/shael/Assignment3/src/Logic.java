import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.Scanner;

public class Logic implements CompanyDAO{

	@Override
	public void addCompany(Company[] company) {
		// TODO Auto-generated method stub
		/*
		
		*/
		FileOutputStream fo =null;
		ObjectOutputStream os = null;
		try {
			fo = new FileOutputStream("companyData.txt");
			os = new ObjectOutputStream(fo);
			os.writeObject(company);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			try {
				os.close();
				fo.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
		
	}

	@Override
	public Company[] showCompany() {
		// TODO Auto-generated method stub
		FileInputStream fs = null;
		ObjectInputStream is = null;
		Company [] co = null;
		try {
			fs = new FileInputStream("companyData.txt");
			is = new ObjectInputStream(fs);
			Object o = is.readObject();
			co = (Company [])o;
			for (Company i:co){
				System.out.println(i);
			}
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		return co;
	}

}
