package com.nseit.Exception;

public class OutOfRangeException extends Exception {
	public OutOfRangeException(){
		super ("Error : Num Out of range");		// taking adv. of inheritance here
		// prining in the super class data member 
	}
	public OutOfRangeException(String message){
		super(message);
		
	}
	
	public void showMessage(){
		System.out.println(getMessage());
	}
}
