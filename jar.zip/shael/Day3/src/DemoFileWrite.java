import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.util.Scanner;

public class DemoFileWrite {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scanner = new Scanner (System.in);
		String data = scanner.nextLine();
		try {
			FileWriter writer  = new FileWriter("MyFile.txt");
			writer.write(data);
			writer.close();
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		try{
			FileReader reader = new FileReader("MyFile.txt");
			
			byte b = 0;
			do {
				System.out.print((char)reader.read());
			}while(b!=-1);
			/*
			while(b!=-1){
				System.out.print((char)reader.read());
			}
			//System.out.println((char)reader.read());
			reader.close();
			*/
			}catch (FileNotFoundException e ){
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	}

}
