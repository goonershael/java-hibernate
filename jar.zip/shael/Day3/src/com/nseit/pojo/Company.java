package com.nseit.pojo;

import java.io.Serializable;

public class Company implements Serializable{
	private String name, address;
	private long c_Id;
	
	public Company(){
		this.name = "Shael";
		this.address = "Mumbai";
		this.c_Id = 12000L;
	}

	public Company(String name, String address, long c_Id){
		this.name = name ;
		this.address = address;
		this.c_Id = c_Id;
	}

	@Override
	public String toString() {
		return ("name=" + name + ", address=" + address + ", c_Id=" + c_Id);
	}
	
	
}
