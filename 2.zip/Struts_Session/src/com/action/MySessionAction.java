package com.action;

import java.util.Map;

import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;

public class MySessionAction extends ActionSupport{
	@Override
	public String execute() throws Exception{
		Map session = ActionContext.getContext().getSession();
		session.put("logged in", true);
		return SUCCESS;
		
	}
}
