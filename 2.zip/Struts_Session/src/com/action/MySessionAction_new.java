package com.action;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.websocket.Session;

import org.apache.struts2.interceptor.ServletRequestAware;

import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;

import jdk.nashorn.internal.ir.RuntimeNode.Request;

public class MySessionAction_new extends ActionSupport implements ServletRequestAware{
	boolean value;
	HttpSession session;
	public void setValue(boolean value) {
		this.value = value;
	}

	@Override
	public String execute() throws Exception{
		Map session = ActionContext.getContext().getSession();
		System.out.println("logged in");
		setValue((boolean)session.get("logged in"));
		return SUCCESS;
		
	}
	
	public boolean isValue(){
		return value;
	}

	@Override
	public void setServletRequest(HttpServletRequest request) {
		// TODO Auto-generated method stub
		session=request.getSession(false);
	}
	
	
}
