package com.action;

import com.opensymphony.xwork2.ActionInvocation;
import com.opensymphony.xwork2.interceptor.Interceptor;

public class MyLoggingInterceptor implements Interceptor {

	@Override
	public void destroy() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void init() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public String intercept(ActionInvocation invocation) throws Exception {
		// TODO Auto-generated method stub
		String className=invocation.getAction().getClass().getName();
		String result= invocation.invoke();
		long startTime = System.currentTimeMillis();
		System.out.println("Before invoking the calling action : " + className);
		
		long endTime = System.currentTimeMillis();
		System.out.println();
		
		System.out.println("after calling action" + className +"time taken:" + (endTime-startTime));
		return result;
	}
	
}
