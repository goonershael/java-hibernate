package com.action;

import com.opensymphony.xwork2.ActionSupport;

public class WorkFlowAction extends ActionSupport {
	String name;
	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String input(){
		System.out.println("imput()");
		return SUCCESS;
	}
	
	@Override
	public String execute() {
		System.out.println("Execute");
		return SUCCESS;
	}

}
