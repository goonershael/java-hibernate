package com.servlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.dao.AdminDAO;
import com.dao.AdminDAOImpl;
import com.pojo.Pizza;
import com.pojo.Topping;

/**
 * Servlet implementation class DeletePizza
 */
@WebServlet("/DeletePizza")
public class DeletePizza extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public DeletePizza() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		Pizza pizza=new Pizza();
		String name=request.getParameter("pizzaname");
		
		AdminDAO dao=new AdminDAOImpl();
		int records_inserted=dao.deleteTopping(name);
		
		//output
		response.setContentType("text/html");
	    PrintWriter wr =response.getWriter();
	
	    wr.println("<html>");
	    wr.println("<body>");
	    if(records_inserted>0)
	    {
		wr.println("RECORD INSERTED! WELCOME" +pizza.getPizzaname());
		RequestDispatcher dispatcher = request.getRequestDispatcher("admin.html");
		dispatcher.forward(request, response);
	    }
	    else{
		wr.println("Sorry!! Record not inserted");
	    }
	    wr.println("</body>");
	    wr.println("</html>");
	}

}
