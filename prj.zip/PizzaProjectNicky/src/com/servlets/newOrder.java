package com.servlets;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.dao.OrderDAO;
import com.dao.OrderDAOImpl;
import com.pojo.Order;

/**
 * Servlet implementation class newOrder
 */
@WebServlet("/newOrder")
public class newOrder extends HttpServlet {
	private static final long serialVersionUID = 1L;

    /**
     * Default constructor. 
     */
    public newOrder() {
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		String from = request.getParameter("from");
		List<Order> orderlist = new ArrayList<Order>();
		RequestDispatcher dispatcher = null;
		
		HttpSession session = request.getSession();
		System.out.println(from);
		
		if(from.equals("addtocart"))
		{
			Order order = new Order();
			
			orderlist = (List<Order>) session.getAttribute("list");
			
			order.setPizzaid(Integer.parseInt(request.getParameter("pizzaid")));
			order.setTotalprice(Integer.parseInt(request.getParameter("pizzaprice")));
			
			String topping="";
			
			String[] ingredients = request.getParameterValues("topping");
			
			if(ingredients!=null)
			{
				topping = ingredients[0];
				for(int i = 1; i<ingredients.length;i++)
				{
					topping = topping+","+ingredients[i];
				}
			}
			order.setExtraToppings(topping);
			order.setUserid(Integer.parseInt(request.getSession().getAttribute("userid").toString()));
			order.setSessionid(request.getSession().getId());
			orderlist.add(order);
			session.setAttribute("list", orderlist);
			dispatcher = request.getRequestDispatcher("order.jsp");
			dispatcher.forward(request, response);
			
		
		}
		else if(from.equals("cart")){
			dispatcher = request.getRequestDispatcher("cart.jsp");
			System.out.println(request.getSession().getId());
			dispatcher.forward(request, response);
			System.out.println(request.getSession().getId());
		}
		else if(from.equals("remove")){
			orderlist = (List<Order>) session.getAttribute("list");
			int index = Integer.parseInt(request.getParameter("someid"))-1;
			orderlist.remove(index);
			session.setAttribute("list", orderlist);
			dispatcher = request.getRequestDispatcher("cart.jsp");
			dispatcher.forward(request, response);
			
		}
		else if(from.equals("confirm")){
			orderlist = (List<Order>) session.getAttribute("list");
			OrderDAO order = new OrderDAOImpl();
			for(Order ord: orderlist){
			order.addOrder(ord);
			}

			System.out.println(request.getSession().getId());
			orderlist = order.showOrderbySession((Integer)request.getSession().getAttribute("userid"), request.getSession().getId());
			System.out.println(orderlist);
			request.setAttribute("orders", orderlist);
			dispatcher = request.getRequestDispatcher("order1.jsp");
			dispatcher.forward(request, response);
		}
		
		
	}

}
