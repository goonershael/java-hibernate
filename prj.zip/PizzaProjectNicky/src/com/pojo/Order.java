package com.pojo;

import java.util.List;

import javax.persistence.*;

@Entity
public class Order {

	@Id
	private int orderid;
	
	private int totalprice;
	private int userid;
	private int pizzaid;
	private String sessionid,extraToppings;
	
	@OneToMany(mappedBy="order", cascade=CascadeType.ALL)
	private List<Pizza> pizzas;
	
	@OneToMany(mappedBy="order", cascade=CascadeType.ALL)
	private List<Topping> toppings;
	
	@OneToMany(mappedBy="order", cascade=CascadeType.ALL)
	private List<User> user;

	public int getOrderid() {
		return orderid;
	}

	public void setOrderid(int orderid) {
		this.orderid = orderid;
	}

	public int getTotalprice() {
		return totalprice;
	}

	public void setTotalprice(int totalprice) {
		this.totalprice = totalprice;
	}

	public int getUserid() {
		return userid;
	}

	public void setUserid(int userid) {
		this.userid = userid;
	}

	public int getPizzaid() {
		return pizzaid;
	}

	public void setPizzaid(int pizzaid) {
		this.pizzaid = pizzaid;
	}

	public String getSessionid() {
		return sessionid;
	}

	public void setSessionid(String sessionid) {
		this.sessionid = sessionid;
	}

	public String getExtraToppings() {
		return extraToppings;
	}

	public void setExtraToppings(String extraToppings) {
		this.extraToppings = extraToppings;
	}

	public List<Pizza> getPizzas() {
		return pizzas;
	}

	public void setPizzas(List<Pizza> pizzas) {
		this.pizzas = pizzas;
	}

	public List<Topping> getToppings() {
		return toppings;
	}

	public void setToppings(List<Topping> toppings) {
		this.toppings = toppings;
	}

	public List<User> getUser() {
		return user;
	}

	public void setUser(List<User> user) {
		this.user = user;
	}

	public Order(int orderid, int totalprice, int userid, int pizzaid, String sessionid, String extraToppings,
			List<Pizza> pizzas, List<Topping> toppings, List<User> user) {
		super();
		this.orderid = orderid;
		this.totalprice = totalprice;
		this.userid = userid;
		this.pizzaid = pizzaid;
		this.sessionid = sessionid;
		this.extraToppings = extraToppings;
		this.pizzas = pizzas;
		this.toppings = toppings;
		this.user = user;
	}

	@Override
	public String toString() {
		return "Order [orderid=" + orderid + ", totalprice=" + totalprice + ", userid=" + userid + ", pizzaid="
				+ pizzaid + ", sessionid=" + sessionid + ", extraToppings=" + extraToppings + ", pizzas=" + pizzas
				+ ", toppings=" + toppings + ", user=" + user + "]";
	}
	public Order() {
		// TODO Auto-generated constructor stub
	}
	
}
