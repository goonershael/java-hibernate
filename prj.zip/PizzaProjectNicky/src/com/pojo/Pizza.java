package com.pojo;

import javax.persistence.*;

@Entity
public class Pizza {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int pizzaid;
	
	private int baseprice;
	private String pizzaname;
	private String ingredients;
	private String crust;
	private String type;
	
	@ManyToOne
	@JoinColumn(name="orderid", nullable=false)
	private Order order;

	public int getPizzaid() {
		return pizzaid;
	}

	public void setPizzaid(int pizzaid) {
		this.pizzaid = pizzaid;
	}

	public int getBaseprice() {
		return baseprice;
	}

	public void setBaseprice(int baseprice) {
		this.baseprice = baseprice;
	}

	public String getPizzaname() {
		return pizzaname;
	}

	public void setPizzaname(String pizzaname) {
		this.pizzaname = pizzaname;
	}

	public String getIngredients() {
		return ingredients;
	}

	public void setIngredients(String ingredients) {
		this.ingredients = ingredients;
	}

	public String getCrust() {
		return crust;
	}

	public void setCrust(String crust) {
		this.crust = crust;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public Order getOrder() {
		return order;
	}

	public void setOrder(Order order) {
		this.order = order;
	}

	public Pizza(int pizzaid, int baseprice, String pizzaname, String ingredients, String crust, String type,
			Order order) {
		super();
		this.pizzaid = pizzaid;
		this.baseprice = baseprice;
		this.pizzaname = pizzaname;
		this.ingredients = ingredients;
		this.crust = crust;
		this.type = type;
		this.order = order;
	}

	@Override
	public String toString() {
		return "Pizza [pizzaid=" + pizzaid + ", baseprice=" + baseprice + ", pizzaname=" + pizzaname + ", ingredients="
				+ ingredients + ", crust=" + crust + ", type=" + type + ", order=" + order + "]";
	}
	
	public Pizza() {
		// TODO Auto-generated constructor stub
	}
}
