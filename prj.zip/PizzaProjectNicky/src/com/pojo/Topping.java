package com.pojo;

import javax.persistence.*;

@Entity
public class Topping {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int toppingid;
	
	private int toppingprice;
	private String toppingname;
	
	@ManyToOne
	@JoinColumn(name="orderid", nullable=false)
	private Order order;

	public int getToppingid() {
		return toppingid;
	}

	public void setToppingid(int toppingid) {
		this.toppingid = toppingid;
	}

	public int getToppingprice() {
		return toppingprice;
	}

	public void setToppingprice(int toppingprice) {
		this.toppingprice = toppingprice;
	}

	public String getToppingname() {
		return toppingname;
	}

	public void setToppingname(String toppingname) {
		this.toppingname = toppingname;
	}

	public Order getOrder() {
		return order;
	}

	public void setOrder(Order order) {
		this.order = order;
	}

	public Topping(int toppingid, int toppingprice, String toppingname, Order order) {
		super();
		this.toppingid = toppingid;
		this.toppingprice = toppingprice;
		this.toppingname = toppingname;
		this.order = order;
	}

	@Override
	public String toString() {
		return "Topping [toppingid=" + toppingid + ", toppingprice=" + toppingprice + ", toppingname=" + toppingname
				+ ", order=" + order + "]";
	}
	
	public Topping() {
		// TODO Auto-generated constructor stub
	}
}
