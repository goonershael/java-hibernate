package com.dao;

import java.util.List;

import com.pojo.Topping;

public interface ToppingDAO {
	public List<Topping> showAllToppings();
	public Topping showToppingByID(int toppingid);
	public Integer addTopping(Topping topping);

}
