package com.dao;

import java.util.List;

import com.pojo.Pizza;

public interface PizzaDAO {
	public Pizza showPizzaById(int pizzaid);
	public List<Pizza> showAllPizza();
	public Integer addPizza(Pizza pizza);

}
