package com.dao;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.criterion.Restrictions;

import com.pojo.Topping;

public class ToppingDAOImpl implements ToppingDAO {
	private static SessionFactory sf = new Configuration().configure().buildSessionFactory();

	@Override
	public List<Topping> showAllToppings() {
		// TODO Auto-generated method stub
		Session session = sf.openSession();
		Transaction tr = session.beginTransaction();
		
		List<Topping> res = session.createCriteria(Topping.class).list();
		
		tr.commit();
		session.close();
		
		return res;
	}

	@Override
	public Topping showToppingByID(int toppingid) {
		// TODO Auto-generated method stub
		Session session = sf.openSession();
		Transaction tr = session.beginTransaction();
		
		Criteria cr = session.createCriteria(Topping.class);
		cr.add(Restrictions.eq("toppingid", toppingid));

		List<Topping> res = cr.list();
		
		tr.commit();
		session.close();
		
		return res.get(0);
	}

	@Override
	public Integer addTopping(Topping topping) {
		// TODO Auto-generated method stub
		Session session = sf.openSession();
		Transaction tr = session.beginTransaction();
		
		Integer toppingid = (Integer) session.save(topping);
		
		tr.commit();
		session.close();
		
		return toppingid;
	}

}
