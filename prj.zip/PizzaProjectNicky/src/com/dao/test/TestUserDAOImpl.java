package com.dao.test;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.dao.AdminDAO;
import com.dao.AdminDAOImpl;
import com.dao.UserDAO;
import com.dao.UserDAOImpl;
import com.pojo.Topping;
import com.pojo.User;

public class TestUserDAOImpl {

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testvalidate() {
		User user=new User();
		User r=new User();
		user.setName("xyz");
		user.setPassword("xyz123");
		
		UserDAO dao=new UserDAOImpl();
		 r=dao.validate("username","password");
		assertEquals(user, r);
	}
	public void testvalidate_negative() {
		User user=new User();
		User r=new User();
		user.setName("xyz");
		user.setPassword("xyz123");
		
		UserDAO dao=new UserDAOImpl();
		 r=dao.validate("username","password");
		assertEquals(user, r);
		assertTrue(r!=user);
	}
	
	
	@Test
	public void testRegister() {
		User user=new User();
		user.setName("xyz");
		user.setPassword("xyz123");
		user.setEmail("xyz@gmail.com");
		user.setAddress("Andheri");
		
		UserDAO dao=new UserDAOImpl();
		int r=dao.Register(user);
		assertEquals(1, r);
	}
	public void testRegister_negative() {
		User user=new User();
		user.setName("xyz");
		user.setPassword("xyz123");
		user.setEmail("xyz@gmail.com");
		user.setAddress("Andheri");
		
		UserDAO dao=new UserDAOImpl();
		int r=dao.Register(user);
		assertEquals(1, r);
		assertTrue(r!=1);
	}

}
