package com.dao.test;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.dao.AdminDAO;
import com.dao.AdminDAOImpl;
import com.pojo.Pizza;
import com.pojo.Topping;

public class TestAdminDAOImpl {

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testAddTopping() {
		Topping topping=new Topping();
		topping.setToppingname("paneer");
		topping.setToppingprice(55);
		
		AdminDAO dao=new AdminDAOImpl();
		int r=dao.addTopping(topping);
		assertEquals(1, r);
	}
	public void testAddTopping_negative() {
		Topping topping=new Topping();
		topping.setToppingname("paneer");
		topping.setToppingprice(55);
		
		AdminDAO dao=new AdminDAOImpl();
		int r=dao.addTopping(topping);
		assertEquals(1, r);
		assertTrue(r==0);
	}
	
	
	
	@Test
	public void testDeleteTopping() {
		Topping topping=new Topping();
	    topping.setToppingname("paneer");
		
		AdminDAO dao=new AdminDAOImpl();
		int r=dao.deleteTopping("toppingname");
		assertEquals(1, r);
	}
	public void testDeleteTopping_negative() {
		Topping topping=new Topping();
		topping.setToppingname("paneer");
		
		AdminDAO dao=new AdminDAOImpl();
		int r=dao.deleteTopping("toppingname");
		assertEquals(1, r);
		assertTrue(r==0);
	}
	
	
	
	@Test
	public void testAddPizza() {
		Pizza pizza=new Pizza();
		pizza.setName("Margarita");
		pizza.setIngredients("Paneer Corn Olives");
		
		AdminDAO dao=new AdminDAOImpl();
		int r=dao.addPizza(pizza);
		assertEquals(1, r);
	}
	public void testAddPizza_negative() {
		Pizza pizza=new Pizza();
		pizza.setName("Margarita");
		pizza.setIngredients("Paneer Corn Olives");
		pizza.setCrust("Thin cheese_burst");
		pizza.setType("Veg");
		pizza.setBaseprice(150);
		
		AdminDAO dao=new AdminDAOImpl();
		int r=dao.addPizza(pizza);
		assertEquals(1, r);
		assertTrue(r==0);
	}
	
	
	
	@Test
	public void testDeletePizza() {
		Pizza pizza=new Pizza();
		pizza.setName("Margarita");
		
		AdminDAO dao=new AdminDAOImpl();
		int r=dao.deletePizza("pizzaname");
		assertEquals(1, r);
	}
	public void testDeletePizza_negative() {
		Pizza pizza=new Pizza();
		pizza.setName("Margarita");
		
		AdminDAO dao=new AdminDAOImpl();
		int r=dao.deletePizza("pizzaname");
		assertEquals(1, r);
		assertTrue(r==0);
	}
	
	
	
	@Test
	public void testUpdatePrice() {
		Pizza pizza=new Pizza();
		pizza.setName("Margarita");
		pizza.setBaseprice(200);
		
		AdminDAO dao=new AdminDAOImpl();
		int r=dao.updatePrice(200,"pizzaname");
		assertEquals(1, r);
	}
	public void testUpdatePrice_negative() {
		Pizza pizza=new Pizza();
		pizza.setName("Margarita");
		pizza.setBaseprice(200);
		
		AdminDAO dao=new AdminDAOImpl();
		int r=dao.updatePrice(200,"pizzaname");
		assertEquals(1, r);
		assertTrue(r==0);
	}
	

}
