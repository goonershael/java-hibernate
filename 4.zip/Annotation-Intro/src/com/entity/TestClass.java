package com.entity;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.cfg.annotations.*;

public class TestClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Session session = null;
		SessionFactory factory;
		Transaction tr = null;
		try{

			factory = new Configuration().configure().buildSessionFactory();
			session = factory.openSession();
			tr = session.beginTransaction();
			Employee_Annot annot = new Employee_Annot();
			annot.setId(1601);
			annot.setFirstName("Shael");
			annot.setLastName("K");
			annot.setSalary(10000);
			session.save(annot);
			tr.commit();
		}catch(Throwable e){
			e.printStackTrace();
		}
	}

}
