package com.carts;

import java.util.Set;

import javax.persistence.*;

@Entity
@Table(name="CART")
public class Cart {
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name ="cart_id")
	private long id;
	
	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public double getTotal() {
		return total;
	}

	public void setTotal(double total) {
		this.total = total;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Set<Items1> getItems1() {
		return items1;
	}

	public void setItems1(Set<Items1> items1) {
		this.items1 = items1;
	}

	@Column(name = "total")
	private double total;
	
	@Column(name ="name")
	private String name;
	
	@OneToMany(mappedBy="cart1", cascade=CascadeType.ALL, fetch=FetchType.LAZY)
	private Set<Items1> items1;
	
}
