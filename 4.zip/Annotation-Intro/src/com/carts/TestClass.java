package com.carts;

import java.util.HashSet;
import java.util.Set;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class TestClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Cart cart = new Cart();
		cart.setName("MyCart1");
		
		Items1 item1 = new Items1("110", 10, 1,cart);
		Items1 item2 = new Items1("110", 20, 2,cart);
//		Items1 items1 = new Items1("110", 10, 1,cart);
		Set<Items1> itemSet = new HashSet<Items1>() ;
		itemSet.add(item1);
		itemSet.add(item2);
		
		cart.setItems1(itemSet);
		cart.setTotal(10 * 1 + 20 *2);
		
		Session session = null;
		SessionFactory factory;
		Transaction tr = null;
		try{

			factory = new Configuration().configure().buildSessionFactory();
			session = factory.openSession();
			tr = session.beginTransaction();
			session.save(cart);
			tr.commit();
		}catch(Throwable e){
			e.printStackTrace();
		}
	}

}
