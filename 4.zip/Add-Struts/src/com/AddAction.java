package com;

public class AddAction {
	private int Num1;
	private String result;
	private int Num2;
	
	public String getResult() {
		return result;
	}

	public void setResult(String result) {
		this.result = result;
	}

	public int getNum1() {
		return Num1;
	}

	public void setNum1(int num1) {
		Num1 = num1;
	}

	public int getNum2() {
		return Num2;
	}

	public void setNum2(int num2) {
		Num2 = num2;
	}


	
	public AddAction() {
		// TODO Auto-generated constructor stub
	}
	
	public String execute(){
		setResult("Sum of  " + getNum1() + " & " + getNum2() +" = " + (getNum1()+getNum2()));
		return "result";
	}
}
