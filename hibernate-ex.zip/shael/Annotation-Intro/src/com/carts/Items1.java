package com.carts;

import javax.persistence.*;

@Entity
@Table(name ="items")
public class Items1 {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="id")
	private long id;
	
	@Column (name ="itemId")
	private String itemId;
	
//	@Column(name="cart_id")
//	private String cart_id;
//	
	@Column(name="item_total")
	private double item_total;
	
	@Column(name ="quantity")
	private int quantity;
	
	@ManyToOne
	@JoinColumn(name="cart_id", nullable=false)
	private Cart cart1;
	
	public Items1(){
		
	}

	public Items1(String itemId, double item_total, int quantity, Cart cart1) {
		super();
		this.itemId = itemId;
		this.item_total = item_total;
		this.quantity = quantity;
		this.cart1 = cart1;
	}
	
	
	
}
