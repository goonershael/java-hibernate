package com.entity;

import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.hibernate.Criteria;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.criterion.Restrictions;
import org.hibernate.transform.Transformers;

public class TestClass {
	private static SessionFactory factory;
	public Integer addEmployee(String fname, String lname, int salary){
		Session session = factory.openSession();
		Transaction tr = null;
		int employeeID = 0;
		try{

			factory = new Configuration().configure().buildSessionFactory();
			session = factory.openSession();
			tr = session.beginTransaction();
			Employee employee = new Employee(fname, lname, salary);
			employeeID = (Integer) session.save(employee);
			tr.commit();
		}catch(HibernateException e){
			if(tr != null)
				tr.rollback();
			e.printStackTrace();
		}
		finally{
			session.close();
		}
		return employeeID;
		
	}

	public List listEmployee(){
		Session session = factory.openSession();
		Transaction tr = null;
		List employees = null;
		try{
			tr = session.beginTransaction();
			
			Criteria cr = session.createCriteria(Employee.class);
			cr.add(Restrictions.lt("salary", 30000));
			employees=cr.list();
			tr.commit();
		}catch(HibernateException e){
			if(tr!=null)
				tr.rollback();
		e.printStackTrace();
		}finally{
			session.close();
		}
		return employees;
		
	}
	
	public List sortEmployeeBySalary(){
		Session session = factory.openSession();
		Transaction tr = null;
		List employees = null;
		try{
			tr = session.beginTransaction();
			
			Criteria cr = session.createCriteria(Employee.class);
			cr.add(Restrictions.lt("salary", 30000));
			employees=cr.list();
			tr.commit();
		}catch(Exception e){
//			if(tr!=null)
//				tr.rollback();
		e.printStackTrace();
		}finally{
			session.close();
		}
		return employees;
		
	}
	
	public List findByCol(){
		Session session = factory.openSession();
		Transaction tr = null;
		List<?> rows = null;
		try{
			tr = session.beginTransaction();
			
			String HQL_QUERY = "select emp.id as emp_id,"
					+ "emp.firstName as emp_name from Employee"
					+ " emp where salary=:sal";
			
			
			Query query = session.createQuery(HQL_QUERY);
			query.setInteger("sal", 50000);
			query.setResultTransformer(Transformers.ALIAS_TO_ENTITY_MAP);
			rows = query.list();
		}catch(Exception e){
			e.printStackTrace();
		}
		return rows;
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try{
			factory = new Configuration().configure().buildSessionFactory();
			TestClass ts = new TestClass();
			Integer empID  = ts.addEmployee("shael", "k", 10000);
			Integer empID1  = ts.addEmployee("abc", "xyz", 20000);
			Integer empID2  = ts.addEmployee("kasdjk", "xyz", 30000);
			Integer empID3  = ts.addEmployee("sahil", "k", 40000);
			Integer empID4  = ts.addEmployee("kkasda", "kdabh", 50000);
			
			List employees = ts.listEmployee();
			for(Iterator iterator = employees.iterator(); iterator.hasNext();){
				Employee employee =(Employee) iterator.next();
				System.out.println("First name : "+employee.getFirstName());
				System.out.println("last name : "+employee.getLastName());
				System.out.println("salary : "+employee.getSalary());	
			}
			System.out.println("-------------------------------------");
			List rows = ts.findByCol();
			for(Object obj : rows){
				Map row = (Map) obj;
				System.out.println("ID : "+row.get("emp_id"));
				System.out.println("first name : "+row.get("emp_name"));
			}
			
		}catch(Exception e){
			e.printStackTrace();
		}
//		SessionFactory factory;
		
	}

}
