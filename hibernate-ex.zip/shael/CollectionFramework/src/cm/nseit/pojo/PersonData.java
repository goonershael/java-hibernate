package cm.nseit.pojo;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class PersonData {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String name = "shael";
		int age  =  24;
		int adh_num = 37891273;
		List<Person> list = new ArrayList<Person>();
		list.add(new Person());
		list.add(new Person ("shael", 24, 37891273));
		list.add(new Person ("nse-it", 14, 37892323));
		list.add(new Person ("raj", 21, 23920));
		//list.add(1354);	//there has to be type safe parameter 
		System.out.println(list);
		System.out.println("Size : " + list.size());
		Iterator<Person> iterator =list.iterator() ;		//no type-casting reqd now as Person type is there
		while(iterator.hasNext()){
			Person myperson = iterator.next();
			//System.out.println("Name : " + myperson.getName()+ "\tAdhar num: " + myperson.getAdh_num());
			if (myperson.getAdh_num() == adh_num){
				System.out.println("Person Found\n" + myperson);
			}
		}
		Person per_found =  new Person(name, age, adh_num);
		list.remove(per_found);
		System.out.println("Size after removal " + list.size());
		System.out.println(list);
	}

}
