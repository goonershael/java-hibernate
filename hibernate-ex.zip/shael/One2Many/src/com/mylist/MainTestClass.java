package com.mylist;

import java.util.ArrayList;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class MainTestClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Session session = null;
		SessionFactory factory;
		Transaction tr = null;
		try{

			factory = new Configuration().configure().buildSessionFactory();
			session = factory.openSession();
			tr = session.beginTransaction();
			Film m1 =  new Film();
			m1.setId(2);
			m1.setName("film1");
			ArrayList list = new ArrayList();
			list.add(new Songs (101, "song1"));
			list.add(new Songs (201, "song1"));
			list.add(new Songs (202, "song2"));
			list.add(new Songs (103, "song1"));
			
			m1.setSongs(list);
			session.save(m1);
			tr.commit();
			System.out.println("Record Added");
		}catch(Exception e){
			e.printStackTrace();
		}
	}
}
