package com.mylist;

import java.util.Iterator;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class TestTwo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Session session = null;
		SessionFactory factory;
		Transaction tr = null;
		try{

			factory = new Configuration().configure().buildSessionFactory();
			session = factory.openSession();
			tr = session.beginTransaction();
			Film m1 = (Film)session.get(Film.class, 2);
			System.out.println(m1.getName());
			List<Songs> list = m1.getSongs();
			for(Iterator iterator = list.iterator(); iterator.hasNext(); ){
				Songs song =(Songs) iterator.next();
				System.out.println(song.getName());
			}
		}catch(Exception e){
			
		}
			
	}

}
