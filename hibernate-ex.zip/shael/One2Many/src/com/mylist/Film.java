package com.mylist;

import java.util.List;

public class Film {
	private int id;
	private String name;
	private List songs;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public List getSongs() {
		return songs;
	}
	public void setSongs(List songs) {
		this.songs = songs;
	}
	
	public Film() {
		super();
	}

	
	
	
}
