package com.set;

import java.util.Date;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class Test2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Session session = null;
		SessionFactory factory;
		Transaction tr = null;
		try{

			factory = new Configuration().configure().buildSessionFactory();
			session = factory.openSession();
			tr = session.beginTransaction();
			
			Stock stock=(Stock) session.get(Stock.class, 1 );
			StockDailyRecord stockDailyRecord = new StockDailyRecord();
			stockDailyRecord.setDaily_record_id(2);
			stockDailyRecord.setPrice_open(new Integer("32"));
			stockDailyRecord.setPrice_close(new Integer("33"));
			Date date = new Date();
			stockDailyRecord.setMyDate(date);
			stock.getStockDailyRecords().add(stockDailyRecord);
			
			session.save(stock);
			tr.commit();
		}catch(Exception e){
			
		}
	}

}
