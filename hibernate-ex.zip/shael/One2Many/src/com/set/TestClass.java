package com.set;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class TestClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Session session = null;
		SessionFactory factory;
		Transaction tr = null;
		try{

			factory = new Configuration().configure().buildSessionFactory();
			session = factory.openSession();
			tr = session.beginTransaction();
			StockDailyRecord stockDailyRecords = new StockDailyRecord();
			stockDailyRecords.setDaily_record_id(new Integer(3));
			stockDailyRecords.setPrice_open(new Integer(31));
			stockDailyRecords.setPrice_close(new Integer(30));
			
			Date date = new Date();
			stockDailyRecords.setMyDate(date);
			
			Set<StockDailyRecord> set = new HashSet<StockDailyRecord>();
			set.add(stockDailyRecords);
			
			Stock stock2 = new Stock();
			stock2.setStock_code("123");
			stock2.setStock_id(2);
			stock2.setStock_name("day 1");
			stock2.getStockDailyRecords().add(stockDailyRecords);
			session.save(stock2);
			tr.commit();
		}catch(Exception e){
			
		}
	}

}
