package com.set;

import java.io.Serializable;
import java.util.Date;

public class StockDailyRecord implements Serializable {
	private int daily_record_id;
	private int price_open;
	private int price_close;
	private Date myDate;
	
	
	public int getDaily_record_id() {
		return daily_record_id;
	}
	public StockDailyRecord() {
		super();
	}
	public void setDaily_record_id(int daily_record_id) {
		this.daily_record_id = daily_record_id;
	}
	public int getPrice_open() {
		return price_open;
	}
	public void setPrice_open(int price_open) {
		this.price_open = price_open;
	}
	public int getPrice_close() {
		return price_close;
	}
	public void setPrice_close(int price_close) {
		this.price_close = price_close;
	}
	public Date getMyDate() {
		return myDate;
	}
	public void setMyDate(Date myDate) {
		this.myDate = myDate;
	}
	
	
}
